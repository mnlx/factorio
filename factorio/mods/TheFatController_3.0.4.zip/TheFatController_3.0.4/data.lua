--player
require("prototypes.fatcontroller")

--styles
require("prototypes.style")

--entity
--require("prototypes.entity.entity")

--items
--require("prototypes.item.items")

--recipies
--require("prototypes.recipe.recipe")